import 'package:get/get.dart';

class AlertsController extends GetxController {}
