import 'package:get/get.dart';

class MessengerController extends GetxController {}
