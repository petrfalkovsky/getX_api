import 'package:get/get.dart';

class ProcentsPageController extends GetxController {}
