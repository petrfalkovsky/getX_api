import 'package:get/get.dart';

class FoltresPage extends GetxController {}
