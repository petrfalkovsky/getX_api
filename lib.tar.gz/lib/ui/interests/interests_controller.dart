import 'package:get/get.dart';

class InterestsController extends GetxController {}
