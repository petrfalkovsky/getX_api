import 'package:get/get.dart';

class ChatPageTwoController extends GetxController {}
