import 'package:get/get.dart';

class ChatPageController extends GetxController {}
