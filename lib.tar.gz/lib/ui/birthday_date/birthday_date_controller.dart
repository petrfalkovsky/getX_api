import 'package:get/get.dart';

class BirthdayDatePageController extends GetxController {}
