import 'package:get/get.dart';

class MyCityPageController extends GetxController {}
